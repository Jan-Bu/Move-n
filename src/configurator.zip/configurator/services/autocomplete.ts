import { czechCities } from '../data/cities';

export function setupAutocomplete(inputEl: HTMLInputElement): void {
  if (!inputEl) return;


  inputEl.setAttribute('autocomplete', 'off');

  // Reuse/assign a stable datalist id for this input
  let datalistId =
    inputEl.getAttribute('data-autocomplete-datalist-id') ||
    buildDatalistId(inputEl);

  inputEl.setAttribute('data-autocomplete-datalist-id', datalistId);
  inputEl.setAttribute('list', datalistId);

  // Create datalist once
  let datalist = document.getElementById(datalistId) as HTMLDataListElement | null;
  if (!datalist) {
    datalist = document.createElement('datalist');
    datalist.id = datalistId;

    inputEl.parentElement?.appendChild(datalist);
  }

 
  seedDatalist(datalist, czechCities);

  const config = getAutocompleteConfig();
  if (config.type === 'google' && config.apiKey) {
    enhanceWithGoogle(inputEl, config.apiKey);
  } else if (config.type === 'photon') {
    enhanceWithPhoton(inputEl, datalist);
  }
}

function buildDatalistId(inputEl: HTMLInputElement): string {

  const base =
    inputEl.id?.trim() ||
    inputEl.name?.trim() ||
    `addr-${Math.random().toString(36).slice(2, 9)}`;
  return `cities-${base}`;
}

interface AutocompleteConfig {
  type: 'none' | 'google' | 'photon';
  apiKey?: string;
}

function getAutocompleteConfig(): AutocompleteConfig {
  const type = (import.meta.env?.VITE_ADDRESS_AUTOCOMPLETE || 'none') as 'none' | 'google' | 'photon';
  const apiKey = import.meta.env?.VITE_GOOGLE_MAPS_API_KEY;
  return { type, apiKey };
}

/* ----------------------------- GOOGLE PLACES ----------------------------- */

function enhanceWithGoogle(inputEl: HTMLInputElement, apiKey: string): void {

  if (typeof window.google === 'undefined' || !window.google?.maps) {
    loadGoogleMaps(apiKey, () => {
      initGoogleAutocomplete(inputEl);
    });
  } else {
    initGoogleAutocomplete(inputEl);
  }
}

function loadGoogleMaps(apiKey: string, callback: () => void): void {

  if (document.querySelector('script[src*="maps.googleapis.com"]')) {
    callback();
    return;
  }

  const script = document.createElement('script');
  script.src = `https://maps.googleapis.com/maps/api/js?key=${encodeURIComponent(apiKey)}&libraries=places`;
  script.async = true;
  script.defer = true;
  script.onload = callback;
  script.onerror = () => {
    console.warn('Google Maps script failed to load.');
  };
  document.head.appendChild(script);
}

function initGoogleAutocomplete(inputEl: HTMLInputElement): void {
  try {
    // @ts-ignore – types mohou chybět podle verze @types/google.maps
    const autocomplete = new google.maps.places.Autocomplete(inputEl, {
      componentRestrictions: { country: 'cz' },
      fields: ['formatted_address', 'name'],

    });

    autocomplete.addListener('place_changed', () => {
      const place = autocomplete.getPlace();
      const value =
        place?.formatted_address ||
        place?.name ||
        inputEl.value;

      if (value) {
        inputEl.value = value;
        inputEl.dispatchEvent(new Event('input', { bubbles: true }));
        inputEl.dispatchEvent(new Event('change', { bubbles: true }));
      }
    });
  } catch (error) {
    console.warn('Google Maps autocomplete failed to initialize:', error);
  }
}

/* --------------------------------- PHOTON -------------------------------- */

function enhanceWithPhoton(inputEl: HTMLInputElement, datalist: HTMLDataListElement): void {
  let timeoutId: number | undefined;
  let controller: AbortController | null = null;

  inputEl.addEventListener('input', () => {
    if (timeoutId) window.clearTimeout(timeoutId);

    const query = inputEl.value.trim();
    if (query.length < 3) {
     
      resetToLocalOnly(datalist);
      return;
    }

    timeoutId = window.setTimeout(async () => {
     
      if (controller) controller.abort();
      controller = new AbortController();

      try {
        const suggestions = await fetchPhotonSuggestions(query, controller.signal);
      
        updateDatalist(datalist, czechCities, suggestions);
      } catch (e) {
        if ((e as any)?.name !== 'AbortError') {
          console.warn('Photon autocomplete failed:', e);
        }
      }
    }, 300);
  });
}

async function fetchPhotonSuggestions(query: string, signal?: AbortSignal): Promise<string[]> {
  const url = `https://photon.komoot.io/api/?q=${encodeURIComponent(query)}&limit=10&lang=cs&bbox=12.0,48.5,18.9,51.1`;
  const response = await fetch(url, { signal });

  if (!response.ok) {
  
    return [];
  }

  const data = await response.json();
  const suggestions: string[] = Array.isArray(data?.features)
    ? data.features.map((feature: any) => {
        const props = feature?.properties || {};
       
        return [props.name, props.city, props.country].filter(Boolean).join(', ');
      })
    : [];

  return suggestions.filter(Boolean);
}

/* ------------------------------- DATALIST UX ------------------------------ */

function seedDatalist(datalist: HTMLDataListElement, values: string[]) {
  datalist.innerHTML = '';
  const fragment = document.createDocumentFragment();
  const seen = new Set<string>();

  for (const v of values) {
    const val = String(v).trim();
    if (!val || seen.has(val)) continue;
    seen.add(val);
    const option = document.createElement('option');
    option.value = val;
    fragment.appendChild(option);
  }
  datalist.appendChild(fragment);
}

function resetToLocalOnly(datalist: HTMLDataListElement) {
  seedDatalist(datalist, czechCities);
}

function updateDatalist(
  datalist: HTMLDataListElement,
  base: string[],
  suggestions: string[]
) {
  const merged = dedupe([...base, ...suggestions]);
  seedDatalist(datalist, merged);
}

function dedupe(arr: string[]): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const item of arr) {
    const key = item.trim();
    if (!key || seen.has(key)) continue;
    seen.add(key);
    out.push(key);
  }
  return out;
}

/* ------------------------------ GLOBAL TYPES ------------------------------ */

declare global {
  interface Window {
    google: any;
  }
  // eslint-disable-next-line no-var
  var google: any;
}
