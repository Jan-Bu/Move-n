export const czechCities = [
  'Praha 1', 'Praha 2', 'Praha 3', 'Praha 4', 'Praha 5', 'Praha 6', 'Praha 7', 'Praha 8', 'Praha 9', 'Praha 10',
  'Brno-střed', 'Brno-sever', 'Brno-jih', 'Královo Pole', 'Líšeň', 'Komárov',
  'Ostrava-centrum', 'Ostrava-jih', 'Ostrava-sever', 'Poruba', 'Slezská Ostrava', 'Moravská Ostrava',
  'Havířov-Město', 'Havířov-Podlesí', 'Havířov-Šumbark',
  'Liberec I', 'Liberec II', 'Liberec III', 'Liberec IV', 'Liberec V',
  'Plzeň 1', 'Plzeň 2', 'Plzeň 3', 'Plzeň 4', 'Bolevec', 'Lochotín',
  'Pardubice I', 'Pardubice II', 'Pardubice III', 'Pardubice IV', 'Zelené Předměstí', 'Polabiny',
  'Benešov', 'Olomouc', 'České Budějovice', 'Hradec Králové', 'Karlovy Vary', 'Ústí nad Labem',
  'Jihlava', 'Most', 'Zlín', 'Kladno', 'Příbram', 'Kutná Hora', 'Frýdek-Místek', 'Kolín',
  'Mladá Boleslav', 'Mělník', 'Beroun', 'Děčín', 'Teplice', 'Chomutov', 'Přerov', 'Třebíč',
  'Tábor', 'Znojmo', 'Prostějov', 'Karviná', 'Opava', 'Havlíčkův Brod', 'Jablonec nad Nisou',
  'Hodonín', 'Vyškov', 'Litoměřice', 'Trutnov', 'Třinec', 'Cheb', 'Písek', 'Nový Jičín',
];
